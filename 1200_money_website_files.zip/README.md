# 1200 Money Website

A responsive black-and-gold artist website starter.

## Included
- Home, Music, Videos, Merch, About, and Contact sections
- Spotify and Apple Music artist links
- Mobile navigation
- Placeholder areas for album covers, video embeds, and artist photo
- Merch-store link placeholder

## Publish with GitHub Pages
1. On GitHub, create a new **public** repository named `1200money-website`.
2. Upload `index.html`, `style.css`, and `script.js` from this folder to the repository root.
3. Open repository **Settings → Pages**.
4. Under Build and deployment, choose **Deploy from a branch**.
5. Select branch `main` and folder `/ (root)`, then click **Save**.
6. Wait a few minutes for GitHub Pages to publish your site.

Your site address will usually be `https://YOUR-USERNAME.github.io/1200money-website/`.

## Add your content
- Replace album tiles with your real cover images and release links.
- Add YouTube embeds by replacing each video placeholder with an iframe. Use YouTube's **Share → Embed** option and copy the iframe code into `index.html`.
- Replace the merch button URL with your own store URL once your storefront is ready.
- Add an artist photo by replacing the placeholder in the About section with an image element.

GitHub Pages hosting is free for public repositories, but its terms prohibit using it as an online business/e-commerce transaction host. Keep product checkout on a separate storefront. Payment providers may charge transaction fees.
